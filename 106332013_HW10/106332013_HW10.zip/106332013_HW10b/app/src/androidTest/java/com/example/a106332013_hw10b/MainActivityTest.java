package com.example.a106332013_hw10b;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

}